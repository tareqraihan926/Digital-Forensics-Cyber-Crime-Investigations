Case Scenario: Confidential Data of Offenders who did Sexual grooming of a Child.
Suspect: Lord Bouse

You have been given a forensic image of Lord Bouse computer. A Group of Persons do Sexual grooming of a Child. They engages in predatory conduct 
to prepare a child person for sexual activity at a later time. They communicate to befriend 
and establish a relationship by emotional connection with the child. In this case A person 
engages in predatory conduct to prepare a child person to befriend and attach with her 
and emotionally or systematically capture her social media id. Their connection was 
established via social media platforms. He has partners for grooming of a child. 